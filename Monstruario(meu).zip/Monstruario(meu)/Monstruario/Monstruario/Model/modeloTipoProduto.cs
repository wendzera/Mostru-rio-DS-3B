﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Monstruario.Model
{
    class modeloTipoProduto
    {
        private int codigo;
        private string nome_tipo;

        public int getCodigo()
        {
            return this.codigo;
        }
        public void setCodigo(int codigo)
        {
            this.codigo = codigo;
           }
        public string getNome_tipo()
        {
            return this.nome_tipo;
        }
        public void setNome_tipo(string nome_tipo)
        {
            this.nome_tipo = nome_tipo;
        }
       
    }
}
