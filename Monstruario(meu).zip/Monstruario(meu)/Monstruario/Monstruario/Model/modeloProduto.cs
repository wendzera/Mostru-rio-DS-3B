﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using Mostruario.Controller;

namespace Monstruario.Model
{
    class modeloProduto
    {
        private int codigo;
        private string nome_produto;
        private float preco_custo;
        private float preco_venda;
        private int quantidade;
        private string descricao;
        private float unidade;
        private DateTime validade;
        private int cod_marca;
        private int cod_tipo;


        public int getCodigo()
        {
            return this.codigo;
        }
        public void setCodigo(int codigo)
        {
            this.codigo = codigo;
        }

        public string getNome_produto()
        {
            return this.nome_produto;
        }

        public void setNome_produto(string nome_produto) 
        {  
            this.nome_produto = nome_produto;
        }

        internal string cadastraProduto(controleProduto mProduto)
        {
            throw new NotImplementedException();
        }

        public float getPreco_custo() 
        { 
            return this.preco_custo;
        }

       

        public void setPreco_custo(float preco_custo)
        {
            this.preco_custo = preco_custo;
        }
        public float getPreco_venda()
        {
            return this.preco_venda;
        }
        public void setPreco_venda(float preco_venda)
        {
            this.preco_venda = preco_venda; 
        }
        public int getQuantidade()
        {
            return this.quantidade;
        }
        public void setQuantidade(int quantidade)
        {
            this.quantidade = quantidade;
        }
        public string getDescricao()
        {
            return this.descricao;
        }
        public void setDescricao(string descricao)
        {
            this.descricao = descricao;
        }
        public float getUnidade()
        {
            return this.unidade;
        }
        public void setUnidade(float unidade)
        {
            this.unidade = unidade;
        }
        public DateTime getValidade()
        {
            return this.validade;
        }
        public void setValidade(DateTime validade)
        {
            this.validade = validade;
        }
        public int getCod_marca()
        {
            return this.cod_marca;
        }
        public void setCod_marca(int cod_marca)
        {
            this.cod_marca = cod_marca;
        }
        public int getCod_tipo()
        {
            return this.cod_tipo;
        }
        public void setCod_tipo(int cod_tipo)
        {
            this.cod_tipo = cod_tipo;
        }

    

    }
}
