﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Npgsql;

namespace Monstruario
{
    class conexãoPG
    {
        //dados sobre o servidor (conexâo)
        static string serverName = "localhost";
        static string port = "5432";
        static string user = "postgres";
        static string passwd = "123456";
        static string dataBase = "produtos";



        //objetos necessários pare comunição com o BD
        NpgsqlConnection conn = null;



        string connString = "Server=" + serverName + ";Port=" + port +
        ";UserID=" + user + ";password=" + passwd + ";Database=" + dataBase + ";";

        public static string produto { get; private set; }

        public NpgsqlConnection conecta()
        {



            try
            {
                conn = new NpgsqlConnection(connString);
                conn.Open();

                return conn;



                /* Retorno do tipo string para teste return "Desconectando ao Postgres" */



            }
            catch (NpgsqlException ex)
            {
                return null;
                /* Retorno do tuipo string para teste return ex.ToString();*/





            }
        }



        public NpgsqlConnection desconecta()
        {
            try
            {
                conn = new NpgsqlConnection(connString);
                conn.Close();
                return conn;



                /* Retorno do tipo string para teste return "Desconectado ao Postgres" */



            }
            catch (NpgsqlException ex)
            {
                return null;
                /* Retorno do tipo string para teste return ex.ToString(); */
            }
        }


    }
}


