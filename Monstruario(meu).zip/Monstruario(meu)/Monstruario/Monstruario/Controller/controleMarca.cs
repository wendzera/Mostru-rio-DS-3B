﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Npgsql;
using Monstruario.Model;
using Monstruario;

namespace Mostruario.Controller
{
    class controleMarca
    {
        //cadastro de novas marcar
        public string cadastraMarca(modeloMarca mMarca)
        {
            string sql = "insert into marca(nomemarca, descmarca) " +
                "values(@nomemarca, @descmarca);";

            conexãoPG con = new conexãoPG();
            NpgsqlConnection conn = con.conecta();
            NpgsqlCommand comm = new NpgsqlCommand(sql, conn);
            try
            {
                comm.Parameters.AddWithValue("@nomemarca", mMarca.getNomeMarca());
                comm.Parameters.AddWithValue("@descmarca", mMarca.getDescricao());

                comm.ExecuteNonQuery();
                return "Marca cadastrada com sucesso!";
            }
            catch (NpgsqlException ex)
            {
                return "Erro ao cadastrar marca!";
            }
        }

        //listagem de marcas sem parâmetro (todas as marcas)
        public NpgsqlDataReader listaMarcas()
        {
            string sql = "select codigomarca, nomemarca from marca";

            conexãoPG con = new conexãoPG();
            NpgsqlConnection conn = con.conecta();
            NpgsqlCommand comm = new NpgsqlCommand(sql, conn);

            try
            {
                return comm.ExecuteReader();
            }
            catch (NpgsqlException ex)
            {
                return null;
            }
        }

    }
}
