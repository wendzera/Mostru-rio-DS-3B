﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Monstruario.View;
using Monstruario.Model; //adiciona pasta com as classes modelo
using Npgsql; //pacote de manipulação do banco de dados 


namespace Monstruario.Controller
{
    class controleTipoProduto
    {
        public string cadastraTipo(modeloTipoProduto mTipo)
        {
            //codigo sql que o método de cadastro vai executar 
            string sql = "insert into tipoproduto(nometipoproduto)" +
                " values(@nometipoproduto);";

            //criar os objetos necessários para conexão
            //objeto da classe conexãoPG
            conexãoPG con = new conexãoPG();

            //objeto npgsqlConnection - mantém o sofware conectado ao banco
            NpgsqlConnection conn = con.conecta();

            //objeto NpgsqlCommand - executa os comandos SQL no banco de dados 
            NpgsqlCommand comm = new NpgsqlCommand(sql, conn);

            //passar valores para o banco:
            try
            {
                //lê o valor do atributo e passa para o banco de dados 
                comm.Parameters.AddWithValue("@nometipoproduto", mTipo.getNome_tipo());

                //executar o comando para gravar no BD
                comm.ExecuteNonQuery();

                //retorno positivo para o formulário
                return "Tipo cadastro com sucesso!";
            }
            catch (NpgsqlException ex)
            {
                return "Erro ao cadastrar tipo!";
            }

          
            }

        internal NpgsqlDataReader listaTipoProduto()
        {
            throw new NotImplementedException();
        }
    }
    public NpgsqlDataReader listaTipoProduto()
    {
        string sql = "select codigotipoproduto, nometipoproduto from tipoproduto";

        conexãoPG con = new conexãoPG();
        NpgsqlConnection conn = con.conecta();
        NpgsqlCommand comm = new NpgsqlCommand(sql, conn);

        try
        {
            return comm.ExecuteReader();
        }
        catch (NpgsqlException ex)
        {
            return null;
        }
    }
    }

