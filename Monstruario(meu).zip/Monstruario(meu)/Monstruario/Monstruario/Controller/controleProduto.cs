﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Npgsql;
using Monstruario.Model;
using Monstruario;

namespace Mostruario.Controller
{
    class controleProduto
    {
        public string cadastraProduto(modeloProduto mProduto)
        {
            string sql = "insert into produto(nome_produto, preco_custo, preco_venda, quantidade, descricao, unidade, validade, cod_marca, cod_tipo) " +
                "values(@nome_produto, @preco_custo, @preco_venda, @quantidade, @descricao, @unidade, @validade, @cod_marca, @cod_tipo);";

            conexãoPG con = new conexãoPG();

            NpgsqlConnection conn = con.conecta();

            NpgsqlCommand comm = new NpgsqlCommand(sql, conn);

            try
            {
                comm.Parameters.AddWithValue("@produto", mProduto.getNome_produto());
                comm.Parameters.AddWithValue("@nome_produto", mProduto.getNome_produto());
                comm.Parameters.AddWithValue("@preco_custo", mProduto.getPreco_custo());
                comm.Parameters.AddWithValue("@preco_venda", mProduto.getPreco_venda());
                comm.Parameters.AddWithValue("@quantidade", mProduto.getQuantidade());
                comm.Parameters.AddWithValue("@descricao", mProduto.getDescricao());
                comm.Parameters.AddWithValue("@unidade", mProduto.getUnidade());
                comm.Parameters.AddWithValue("@validade", mProduto.getValidade());
                comm.Parameters.AddWithValue("@cod_marca", mProduto.getCod_marca());
                comm.Parameters.AddWithValue("@cod_tipo", mProduto.getCod_tipo());

                comm.ExecuteNonQuery();

                return " Produto cadastrado com sucesso!";

            }
            catch (NpgsqlException ex)
            {
                return "Erro ao cadastrar!";
            }

           // public NpgsqlDataReader listaProdutos()
           // {
                //string sql = "select codigo, nome_produto from ";

               // conexãoPG con = new conexãoPG();
               // NpgsqlConnection conn = con.conecta();
                //NpgsqlCommand comm = new NpgsqlCommand(sql, conn);

                //try
               // {
                  //  return comm.ExecuteReader();
               // }
               // catch (NpgsqlException ex)
               // {
                  //  return null;
                //}


            }
        }
    }

