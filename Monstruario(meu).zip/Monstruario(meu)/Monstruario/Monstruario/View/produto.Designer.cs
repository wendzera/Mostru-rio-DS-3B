﻿namespace Monstruario.View
{
    partial class produto
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.txb1cad = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.rtb1cad = new System.Windows.Forms.RichTextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txb2cad = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.nud1cad = new System.Windows.Forms.NumericUpDown();
            this.msktxb1cad = new System.Windows.Forms.MaskedTextBox();
            this.msktxb2cad = new System.Windows.Forms.MaskedTextBox();
            this.dtp1cad = new System.Windows.Forms.DateTimePicker();
            this.cbx1cad = new System.Windows.Forms.ComboBox();
            this.cbx2cad = new System.Windows.Forms.ComboBox();
            this.button2 = new System.Windows.Forms.Button();
            this.btnsavecad = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.linkLabel2 = new System.Windows.Forms.LinkLabel();
            ((System.ComponentModel.ISupportInitialize)(this.nud1cad)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Lucida Fax", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(42, 34);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(236, 27);
            this.label1.TabIndex = 0;
            this.label1.Text = "Cadastrar produto";
            // 
            // txb1cad
            // 
            this.txb1cad.Font = new System.Drawing.Font("MS Reference Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txb1cad.Location = new System.Drawing.Point(47, 108);
            this.txb1cad.Name = "txb1cad";
            this.txb1cad.Size = new System.Drawing.Size(194, 21);
            this.txb1cad.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("MS Reference Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(44, 92);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(45, 15);
            this.label2.TabIndex = 2;
            this.label2.Text = "Nome:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("MS Reference Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(44, 140);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(78, 15);
            this.label4.TabIndex = 3;
            this.label4.Text = "Preço custo:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("MS Reference Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(44, 199);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(83, 15);
            this.label3.TabIndex = 3;
            this.label3.Text = "Preço venda:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("MS Reference Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(300, 269);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(77, 15);
            this.label5.TabIndex = 3;
            this.label5.Text = "Quantidade:";
            // 
            // rtb1cad
            // 
            this.rtb1cad.Font = new System.Drawing.Font("MS Reference Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rtb1cad.Location = new System.Drawing.Point(492, 195);
            this.rtb1cad.Name = "rtb1cad";
            this.rtb1cad.Size = new System.Drawing.Size(183, 190);
            this.rtb1cad.TabIndex = 4;
            this.rtb1cad.Text = "";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("MS Reference Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(489, 179);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(68, 15);
            this.label6.TabIndex = 3;
            this.label6.Text = "Descrição:";
            // 
            // txb2cad
            // 
            this.txb2cad.Font = new System.Drawing.Font("MS Reference Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txb2cad.Location = new System.Drawing.Point(47, 283);
            this.txb2cad.Name = "txb2cad";
            this.txb2cad.Size = new System.Drawing.Size(47, 21);
            this.txb2cad.TabIndex = 1;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("MS Reference Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(44, 267);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(58, 15);
            this.label7.TabIndex = 3;
            this.label7.Text = "Unidade:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("MS Reference Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(303, 93);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(61, 15);
            this.label8.TabIndex = 3;
            this.label8.Text = "Validade:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("MS Reference Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(300, 199);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(63, 15);
            this.label9.TabIndex = 3;
            this.label9.Text = "Cod Tipo:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("MS Reference Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(303, 140);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(73, 15);
            this.label10.TabIndex = 3;
            this.label10.Text = "Cod Marca:";
            // 
            // nud1cad
            // 
            this.nud1cad.Location = new System.Drawing.Point(303, 285);
            this.nud1cad.Name = "nud1cad";
            this.nud1cad.Size = new System.Drawing.Size(42, 20);
            this.nud1cad.TabIndex = 6;
            // 
            // msktxb1cad
            // 
            this.msktxb1cad.Location = new System.Drawing.Point(47, 158);
            this.msktxb1cad.Mask = "0000.00";
            this.msktxb1cad.Name = "msktxb1cad";
            this.msktxb1cad.Size = new System.Drawing.Size(100, 20);
            this.msktxb1cad.TabIndex = 8;
            // 
            // msktxb2cad
            // 
            this.msktxb2cad.Location = new System.Drawing.Point(47, 215);
            this.msktxb2cad.Mask = "0000.00";
            this.msktxb2cad.Name = "msktxb2cad";
            this.msktxb2cad.Size = new System.Drawing.Size(100, 20);
            this.msktxb2cad.TabIndex = 9;
            // 
            // dtp1cad
            // 
            this.dtp1cad.Location = new System.Drawing.Point(306, 108);
            this.dtp1cad.Name = "dtp1cad";
            this.dtp1cad.Size = new System.Drawing.Size(169, 20);
            this.dtp1cad.TabIndex = 10;
            // 
            // cbx1cad
            // 
            this.cbx1cad.FormattingEnabled = true;
            this.cbx1cad.Location = new System.Drawing.Point(306, 158);
            this.cbx1cad.Name = "cbx1cad";
            this.cbx1cad.Size = new System.Drawing.Size(121, 21);
            this.cbx1cad.TabIndex = 11;
            this.cbx1cad.Click += new System.EventHandler(this.loadMarcas_Click);
            // 
            // cbx2cad
            // 
            this.cbx2cad.FormattingEnabled = true;
            this.cbx2cad.Location = new System.Drawing.Point(306, 214);
            this.cbx2cad.Name = "cbx2cad";
            this.cbx2cad.Size = new System.Drawing.Size(121, 21);
            this.cbx2cad.TabIndex = 12;
            this.cbx2cad.Click += new System.EventHandler(this.loadTipo_Click);
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("MS Reference Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(320, 351);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(93, 34);
            this.button2.TabIndex = 14;
            this.button2.Text = "Cancelar";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // btnsavecad
            // 
            this.btnsavecad.Font = new System.Drawing.Font("MS Reference Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnsavecad.Location = new System.Drawing.Point(186, 351);
            this.btnsavecad.Name = "btnsavecad";
            this.btnsavecad.Size = new System.Drawing.Size(93, 34);
            this.btnsavecad.TabIndex = 14;
            this.btnsavecad.Text = "Salvar";
            this.btnsavecad.UseVisualStyleBackColor = true;
            this.btnsavecad.Click += new System.EventHandler(this.novoProduto);
            // 
            // button4
            // 
            this.button4.AutoSize = true;
            this.button4.Font = new System.Drawing.Font("MS Reference Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.Location = new System.Drawing.Point(47, 351);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(93, 34);
            this.button4.TabIndex = 14;
            this.button4.Text = "Novo";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // linkLabel1
            // 
            this.linkLabel1.AutoSize = true;
            this.linkLabel1.Location = new System.Drawing.Point(433, 217);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(31, 13);
            this.linkLabel1.TabIndex = 15;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = "novo";
            this.linkLabel1.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.abrirlink_tipo);
            // 
            // linkLabel2
            // 
            this.linkLabel2.AutoSize = true;
            this.linkLabel2.Location = new System.Drawing.Point(433, 161);
            this.linkLabel2.Name = "linkLabel2";
            this.linkLabel2.Size = new System.Drawing.Size(31, 13);
            this.linkLabel2.TabIndex = 16;
            this.linkLabel2.TabStop = true;
            this.linkLabel2.Text = "novo";
            this.linkLabel2.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.novaMarca);
            // 
            // produto
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(711, 420);
            this.Controls.Add(this.linkLabel2);
            this.Controls.Add(this.linkLabel1);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.btnsavecad);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.cbx2cad);
            this.Controls.Add(this.cbx1cad);
            this.Controls.Add(this.dtp1cad);
            this.Controls.Add(this.msktxb2cad);
            this.Controls.Add(this.msktxb1cad);
            this.Controls.Add(this.nud1cad);
            this.Controls.Add(this.rtb1cad);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txb2cad);
            this.Controls.Add(this.txb1cad);
            this.Controls.Add(this.label1);
            this.Name = "produto";
            this.Text = "produto";
            this.Load += new System.EventHandler(this.cadProduto_Load);
            ((System.ComponentModel.ISupportInitialize)(this.nud1cad)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txb1cad;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.RichTextBox rtb1cad;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txb2cad;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.NumericUpDown nud1cad;
        private System.Windows.Forms.MaskedTextBox msktxb1cad;
        private System.Windows.Forms.MaskedTextBox msktxb2cad;
        private System.Windows.Forms.DateTimePicker dtp1cad;
        private System.Windows.Forms.ComboBox cbx1cad;
        private System.Windows.Forms.ComboBox cbx2cad;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button btnsavecad;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.LinkLabel linkLabel1;
        private System.Windows.Forms.LinkLabel linkLabel2;
    }
}