﻿namespace Monstruario
{
    partial class Principal
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.menuCadastro = new System.Windows.Forms.ToolStripMenuItem();
            this.cadProduto = new System.Windows.Forms.ToolStripMenuItem();
            this.mARCAToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.cadTipoProduto = new System.Windows.Forms.ToolStripMenuItem();
            this.pESQUISASToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pRODUTOToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mARCAToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aTUALIZAÇÃOToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pRODUTOToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.sOBREToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuCadastro,
            this.pESQUISASToolStripMenuItem,
            this.aTUALIZAÇÃOToolStripMenuItem,
            this.sOBREToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            this.menuStrip1.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.menuStrip1_ItemClicked);
            // 
            // menuCadastro
            // 
            this.menuCadastro.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cadProduto,
            this.mARCAToolStripMenuItem1,
            this.cadTipoProduto});
            this.menuCadastro.Font = new System.Drawing.Font("Lucida Fax", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.menuCadastro.Image = global::Monstruario.Properties.Resources.registro;
            this.menuCadastro.Name = "menuCadastro";
            this.menuCadastro.Size = new System.Drawing.Size(110, 20);
            this.menuCadastro.Text = "&CADASTROS";
            this.menuCadastro.Click += new System.EventHandler(this.cadastrosToolStripMenuItem_Click);
            // 
            // cadProduto
            // 
            this.cadProduto.Name = "cadProduto";
            this.cadProduto.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.P)));
            this.cadProduto.Size = new System.Drawing.Size(185, 22);
            this.cadProduto.Text = "PRODUTO";
            this.cadProduto.Click += new System.EventHandler(this.novoProduto);
            // 
            // mARCAToolStripMenuItem1
            // 
            this.mARCAToolStripMenuItem1.Name = "mARCAToolStripMenuItem1";
            this.mARCAToolStripMenuItem1.Size = new System.Drawing.Size(185, 22);
            this.mARCAToolStripMenuItem1.Text = "MARCA";
            this.mARCAToolStripMenuItem1.Click += new System.EventHandler(this.cadMarca);
            // 
            // cadTipoProduto
            // 
            this.cadTipoProduto.Name = "cadTipoProduto";
            this.cadTipoProduto.Size = new System.Drawing.Size(185, 22);
            this.cadTipoProduto.Text = "TIPO DE PRODUTO";
            this.cadTipoProduto.Click += new System.EventHandler(this.frmTipoProduto);
            // 
            // pESQUISASToolStripMenuItem
            // 
            this.pESQUISASToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.pRODUTOToolStripMenuItem,
            this.mARCAToolStripMenuItem});
            this.pESQUISASToolStripMenuItem.Font = new System.Drawing.Font("Lucida Fax", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pESQUISASToolStripMenuItem.Image = global::Monstruario.Properties.Resources.lupa;
            this.pESQUISASToolStripMenuItem.Name = "pESQUISASToolStripMenuItem";
            this.pESQUISASToolStripMenuItem.Size = new System.Drawing.Size(101, 20);
            this.pESQUISASToolStripMenuItem.Text = "PESQUISAS";
            // 
            // pRODUTOToolStripMenuItem
            // 
            this.pRODUTOToolStripMenuItem.Name = "pRODUTOToolStripMenuItem";
            this.pRODUTOToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.pRODUTOToolStripMenuItem.Text = "PRODUTO";
            // 
            // mARCAToolStripMenuItem
            // 
            this.mARCAToolStripMenuItem.Name = "mARCAToolStripMenuItem";
            this.mARCAToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.mARCAToolStripMenuItem.Text = "MARCA";
            // 
            // aTUALIZAÇÃOToolStripMenuItem
            // 
            this.aTUALIZAÇÃOToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.pRODUTOToolStripMenuItem1});
            this.aTUALIZAÇÃOToolStripMenuItem.Font = new System.Drawing.Font("Lucida Fax", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.aTUALIZAÇÃOToolStripMenuItem.Image = global::Monstruario.Properties.Resources.lupa1;
            this.aTUALIZAÇÃOToolStripMenuItem.Name = "aTUALIZAÇÃOToolStripMenuItem";
            this.aTUALIZAÇÃOToolStripMenuItem.Size = new System.Drawing.Size(125, 20);
            this.aTUALIZAÇÃOToolStripMenuItem.Text = "ATUALIZAÇÃO";
            // 
            // pRODUTOToolStripMenuItem1
            // 
            this.pRODUTOToolStripMenuItem1.Name = "pRODUTOToolStripMenuItem1";
            this.pRODUTOToolStripMenuItem1.Size = new System.Drawing.Size(180, 22);
            this.pRODUTOToolStripMenuItem1.Text = "PRODUTO";
            // 
            // sOBREToolStripMenuItem
            // 
            this.sOBREToolStripMenuItem.Font = new System.Drawing.Font("Lucida Fax", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sOBREToolStripMenuItem.Image = global::Monstruario.Properties.Resources.em_formacao;
            this.sOBREToolStripMenuItem.Name = "sOBREToolStripMenuItem";
            this.sOBREToolStripMenuItem.Size = new System.Drawing.Size(73, 20);
            this.sOBREToolStripMenuItem.Text = "SOBRE";
            // 
            // Principal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Monstruario.Properties.Resources.wn;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.menuStrip1);
            this.DoubleBuffered = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Principal";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Principal_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem menuCadastro;
        private System.Windows.Forms.ToolStripMenuItem cadProduto;
        private System.Windows.Forms.ToolStripMenuItem cadTipoProduto;
        private System.Windows.Forms.ToolStripMenuItem pESQUISASToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aTUALIZAÇÃOToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pRODUTOToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mARCAToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pRODUTOToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem sOBREToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mARCAToolStripMenuItem1;
    }
}

