﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Monstruario.Model;
using Monstruario.Controller;
using Mostruario.Controller;
using Npgsql;

namespace Monstruario.View
{
    public partial class produto : Form
    {
        public produto()
        {
            InitializeComponent();
        }

        private void novoProduto(object sender, EventArgs e)
        {
            modeloProduto cProduto = new modeloProduto();
          
            controleProduto mProduto = new controleProduto();
          

            cProduto.setNome_produto(txb1cad.Text);
            cProduto.setDescricao(rtb1cad.Text);
       

            string res = cProduto.cadastraProduto(mProduto);
            MessageBox.Show(res);
        }

        private void cadProduto_Load(object sender, EventArgs e)
        {
            carregaMarcas();
        }

        private void carregaMarcas()
        {
            controleMarca cMarca = new controleMarca();
            NpgsqlDataReader marcas = cMarca.listaMarcas();

            DataTable dtMarcas = new DataTable();

            dtMarcas.Load(marcas);

            cbx1cad.DataSource = dtMarcas;

            cbx1cad.DisplayMember = "nomemarca";

            cbx1cad.ValueMember = "codigomarca";
        }

        private void carregaTipo()
        {
            controleTipoProduto cTipo = new controleTipoProduto();
            NpgsqlDataReader tipos = cTipo.listaTipoProduto();

            DataTable dtTipo = new DataTable();

            dtTipo.Load(tipos);

            cbx2cad.DataSource = dtTipo;

            cbx2cad.DisplayMember = "nometipoproduto";

            cbx2cad.ValueMember = "codigotipoproduto";
        }

        
        private void novaMarca(object sender, LinkLabelLinkClickedEventArgs e)
        {
            cadMarca frm = new cadMarca();
            frm.ShowDialog();
        }

        private void loadMarcas_Click(object sender, EventArgs e)
        {
            carregaMarcas();
        }

        private void loadTipo_Click(object sender, EventArgs e)
        {
            carregaTipo();
        }

        private void abrirlink_tipo(object sender, LinkLabelLinkClickedEventArgs e)
        {
            tipoProduto frm = new tipoProduto();
            frm.ShowDialog();
        }
    }


}
