﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Monstruario.Model;
using Monstruario.Controller;


namespace Monstruario.View
{
    public partial class tipoProduto : Form
    {
        public tipoProduto()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void novoTipo(object sender, EventArgs e)
        {
            //criar os objetos das classes modelo e controle 
            modeloTipoProduto mTipo = new modeloTipoProduto();
            controleTipoProduto cTipo = new controleTipoProduto();

            //salvar os valores dos campos do formulario nos atributos 
            mTipo.setNome_tipo(textBox1.Text);

            // executa o método de cadastro
            string res = cTipo.cadastraTipo(mTipo);

            MessageBox.Show(res);

        }
    }
}
