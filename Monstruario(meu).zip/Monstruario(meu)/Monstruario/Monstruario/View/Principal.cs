﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Monstruario.View;

namespace Monstruario
{
    public partial class Principal : Form
    {
        public Principal()
        {
            InitializeComponent();
        }

        private void cadastrosToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void frmMarca(object sender, EventArgs e)
        {
            
        }

        private void Marca(object sender, EventArgs e)
        {

        }

        private void Principal_Load(object sender, EventArgs e)
        {

        }

        private void cadMarca(object sender, EventArgs e)
        {
            cadMarca frm = new cadMarca();
            frm.ShowDialog();
        }

        private void novoProduto(object sender, EventArgs e)
        {
            produto frm = new produto();
            frm.ShowDialog();
        }

        private void frmTipoProduto(object sender, EventArgs e)
        {
            tipoProduto frm = new tipoProduto();
            frm.ShowDialog();
        }
    }
}
